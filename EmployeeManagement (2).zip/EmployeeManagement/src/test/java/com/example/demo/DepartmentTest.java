package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.internal.Longs;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import com.cg.EmployeeManagement.model.Department;
import com.cg.EmployeeManagement.repository.DepartmentRepository;
import com.cg.EmployeeManagement.service.DepartmentService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DepartmentService.class)
public class DepartmentTest {
	@Autowired
	private DepartmentService departServ;
	@MockBean
	private DepartmentRepository departRepo;

	@Test
	public void testAddDepartmentDetails() throws Exception, Exception  {
		Department depart = new Department();
		depart.setDepartId(123);
		depart.setDepartName("computers");
		depart.toString();
		when(departRepo.save(depart)).thenReturn(depart);
		assertEquals(depart, departServ.addDepartment(depart));
	}
	@Test
	public void testgetalldepartmentdetails() throws Exception, Exception {
		
		List<Department> depart=new ArrayList<Department>();
		Mockito.when(departRepo.findAll()).thenReturn(depart);
		assertEquals(depart,departServ.getAllDepartmentsDetails());
	}
	@Test
	public void testgetalldepartmentdetailsbypagination() throws Exception, Exception {
		
		List<Department> depart=new ArrayList<Department>();
		Mockito.when(departRepo.findAll()).thenReturn(depart);
		assertEquals(depart,departServ.getAllDepartmentDetailsByPagination());
	}
	@Test
    public void testgetalldepartmentcount() {
	when(departRepo.count()).thenReturn((long) 10);
		assertEquals((long)10, (long)departServ.getAllDepartmentCount());
		//Mockito.when(departRepo.count()).thenReturn(depart);
	assertEquals((long) 10,departServ.getAllDepartmentCount());
	}
	@Test
	public void testdeleteDepartment() throws Exception, Exception {
		Department depart = new Department();
		int id=depart.getDepartId();
		departServ.deleteDepart(id);		
	}
}