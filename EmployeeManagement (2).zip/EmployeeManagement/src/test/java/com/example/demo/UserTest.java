package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.EmployeeManagement.exceptions.ApplicationException;
import com.cg.EmployeeManagement.exceptions.BusinessException;
import com.cg.EmployeeManagement.exceptions.DatabaseOperationException;

import com.cg.EmployeeManagement.model.User;
import com.cg.EmployeeManagement.repository.UserRepository;

import com.cg.EmployeeManagement.service.UserService;

@ExtendWith(MockitoExtension.class)
public class UserTest {

	@InjectMocks
	private UserService userService;

	@Mock
	private UserRepository userRepository;
	@Test
	 void testinsert() throws DatabaseOperationException, ApplicationException, BusinessException  {
		
		User user = Mockito.mock(User.class);
		User updated=Mockito.mock(User.class);
		Mockito.when(userRepository.save(user)).thenReturn(updated); 
		User result =userService.insertUser(user);
		assertEquals(updated,result);
}
	@Test
	public void testdelete() 
 {
		User user = new User();
		String userid= user.getUserid() ;
		userService.deleteUserbyId(user);		
	}
       @Test
public void testgetAllUsers() throws Exception, Exception {
		
		List<User> user=new ArrayList<User>();
		Mockito.when(userRepository.findAll()).thenReturn(user);
		assertEquals(user,userService.getAllUsers());
       }
	
}