package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.EmployeeManagement.exceptions.ApplicationException;
import com.cg.EmployeeManagement.exceptions.BusinessException;
import com.cg.EmployeeManagement.exceptions.DatabaseOperationException;
import com.cg.EmployeeManagement.model.Department;
import com.cg.EmployeeManagement.model.Employee;
import com.cg.EmployeeManagement.repository.EmployeeRepository;
import com.cg.EmployeeManagement.service.EmployeeService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = EmployeeService.class)
public class EmployeeTest {
	@Autowired
	private EmployeeService employeeService;
	@MockBean
	private EmployeeRepository employeeRepository;
	
	@Test
	public void testAddEmployeeDetails() throws Exception, Exception  {
		Employee employee = new Employee();
		employee.setUserId(123);
		employee.setFirstName("Sai");
		employee.setFirstName("Prakash");
		LocalDate dob=LocalDate.of(1989, 8, 8);
		employee.setDob(dob);
		employee.setEmail("prakash@gmail.com");
		Department depart=new Department();
		depart.setDepartName("computers");
		employee.setDepartment(depart);
		employee.toString();
		when(employeeRepository.save(employee)).thenReturn(employee);
		assertEquals(employee, employeeService.addEmployee(employee));
	}
	
	@Test
	public void testdeleteEmployee() throws Exception, Exception {
		Employee employee = new Employee();
		int empId=employee.getUserId();
		employeeService.deleteEmployee(empId);	
	}
	
	@Test
	public void testUpdateCustomer() throws DatabaseOperationException, ApplicationException, BusinessException  {
		
		Employee employee = Mockito.mock(Employee.class);
		Employee updated=Mockito.mock(Employee.class);
		int customerId=5;
		Mockito.when(employee.getUserId()).thenReturn(customerId);
		Mockito.when(employeeRepository.existsById(customerId)).thenReturn(true);
			
		
		Mockito.when(employeeRepository.save(employee)).thenReturn(updated); 
		Employee result =employeeService.updateEmployee(employee);
		assertEquals(updated,result);

	}
	@Test
	public void testgetallemployeedetails() throws Exception, Exception {
		
		List<Employee> employee=new ArrayList<Employee>();
		Mockito.when(employeeRepository.findAll()).thenReturn(employee);
		assertEquals(employee,employeeService.getAllEmployees());
	}
	
	@Test
	public void testgetallemployeetdetailsbypagination() throws Exception, Exception {
		
		List<Employee> employee=new ArrayList<Employee>();
		Mockito.when(employeeRepository.findAll()).thenReturn(employee);
		assertEquals(employee,employeeService.getAllEmployeesByPagination(null, null));
	}
	
	@Test
    public void testgetalldepartmentcount() throws DatabaseOperationException, ApplicationException {
	when(employeeRepository.count()).thenReturn((long) 10);
		assertEquals((long)10, (long)employeeService.getAllEmployeeCount());
		//Mockito.when(departRepo.count()).thenReturn(depart);
	assertEquals((long) 10,employeeService.getAllEmployeeCount());
	}


}