package com.cg.EmployeeManagement.model;



import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.CascadeType;

@Entity
public class Compliance implements Serializable {
private static final long serialVersionUID = 1L;
@Id

	private int complainceId;
	private String rlType;
	private String details;
	private LocalDate createDate;
	@OneToOne(cascade = {CascadeType.ALL})
    private Department department;
	private int empCount;
	private int stsCount;
	private String status;
	
	
	public   int getComplainceId() {
		return complainceId;
	}
	public void setComplainceId(int complainceId) {
		this.complainceId = complainceId;
	}
	public String getRlType() {
		return rlType;
	}
	public void setRlType(String rlType) {
		this.rlType = rlType;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public LocalDate getCreateDate() {
		return createDate;
	}
	public void setCreateDate(LocalDate createDate) {
		this.createDate = createDate;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public int getEmpCount() {
		return empCount;
	}
	public void setEmpCount(int empCount) {
		this.empCount = empCount;
	}
	public int getStsCount() {
		return stsCount;
	}
	public void setStsCount(int stsCount) {
		this.stsCount = stsCount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Compliance [complainceId=" + complainceId + ", rlType=" + rlType + ", details=" + details
				+ ", createDate=" + createDate + ", department=" + department + ", empCount=" + empCount + ", stsCount="
				+ stsCount + ", status=" + status + "]";
	}

	}