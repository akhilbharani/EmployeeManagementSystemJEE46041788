package com.cg.EmployeeManagement.model;


import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


@Entity
public class StatusReport implements Serializable {

private static final long serialVersionUID = 1L;
@Id

	private int statusId;
	private String comments;
	private String details;
	private LocalDate createDate;
	private String userId;
	private int complainceId;
	@OneToOne(cascade = {CascadeType.ALL})
	private Department department;
	



	public int getStatusId() {
		return statusId;
	}

	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public LocalDate getCreateDate() {
		return createDate;
	}

	public void setCreateDate(LocalDate createDate) {
		this.createDate = createDate;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getComplianceId() {
		return complainceId;
	}

	public void setComplianceId(int complianceId) {
		this.complainceId = complianceId;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "StatusReport [statusId=" + statusId + ", comments=" + comments + ", details=" + details
				+ ", createDate=" + createDate + ", userId=" + userId + ", complianceId=" + complainceId
				+ ", department=" + department + "]";
	}
	
	



	

}