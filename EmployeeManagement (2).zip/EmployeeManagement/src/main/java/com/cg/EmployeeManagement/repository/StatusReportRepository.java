package com.cg.EmployeeManagement.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.EmployeeManagement.model.StatusReport;

@Repository
public interface StatusReportRepository extends JpaRepository<StatusReport, Integer>{
	@Query(" from StatusReport where (userId=:userId and complianceId=:complianceId )")
	public List<StatusReport> findByUserIdAndComplainceId(@Param("userId")int userId,@Param("complianceId")int complainceId) ;
	
}