package com.cg.EmployeeManagement.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.EmployeeManagement.exceptions.ApplicationException;
import com.cg.EmployeeManagement.exceptions.DatabaseOperationException;
import com.cg.EmployeeManagement.model.Department;
import com.cg.EmployeeManagement.service.DepartmentService;

@RestController
public class DepartmentController {

	@Autowired
	public DepartmentService deptServ;

	@PostMapping("/adddepartmentdetails")
	public ResponseEntity<Department> addDepartmentDetails(@RequestBody Department department)
	{ 
		
		try {
			Department result = deptServ.addDepartment(department);
			return new ResponseEntity<Department>(result, HttpStatus.OK);
		} catch (ApplicationException | DatabaseOperationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		}
	
	@GetMapping("/getalldepartmentsdetails")
	public List<Department> getAllDepartmentDetails()  {
		
		
		try {List<Department> result = deptServ.getAllDepartmentsDetails();
		return result;
			
		} catch (ApplicationException | DatabaseOperationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
		

	@GetMapping("/getalldepartmentsdetailsbypagination")
	public List<Department> getAllDepartmentDetailsByPagination()
			 {
		
		try {
			List<Department> result = deptServ.getAllDepartmentDetailsByPagination();
			return result;
			
		} catch (ApplicationException | DatabaseOperationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
	

	@GetMapping("/getalldepartmentcount")
	public long getAllDepartmentCount() {
		return deptServ.getAllDepartmentCount();
	}
	
	@GetMapping("throwException")
	public String getException() throws ApplicationException {
		Department dept = null;;
		dept.getDepartId();
		return "hello";
	}

	@DeleteMapping("/deletedepartmentbyid/{id}")
	public void deleteDepartmentById(@PathVariable int id) {
		try {
			deptServ.deleteDepart(id);
		} catch (ApplicationException | DatabaseOperationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}