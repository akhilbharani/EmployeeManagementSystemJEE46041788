package com.cg.EmployeeManagement.model;
import javax.persistence.Entity;

import javax.persistence.Id;
@Entity
	public class User {
@Id
		private String userid;
		
		private String password;	
		
		private String role;	

		private int result;
		
		public String getUserid() {
			return userid;
		}

		public void setUserid(String userid) {
			this.userid = userid;
		}

		public String getRole() {
			return role;
		}
		
		public void setRole(String role) {
			this.role = role;
		}

		public String getPassword() {
			return password;
		}
				public void setPassword(final String password) {
			this.password = password;
		}
		
		public int getResult() {
			return result;
		}

		public void setResult(int result) {
			this.result = result;
		}

		@Override
		public String toString() {
			return "User [userid=" + userid + ", password=" + password + ", role=" + role + ", result=" + result + "]";
		}


		

	}


