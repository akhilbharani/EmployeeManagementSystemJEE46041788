package com.cg.EmployeeManagement.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.EmployeeManagement.exceptions.ApplicationException;
import com.cg.EmployeeManagement.exceptions.BusinessException;
import com.cg.EmployeeManagement.exceptions.DatabaseOperationException;

import com.cg.EmployeeManagement.model.User;
import com.cg.EmployeeManagement.repository.UserRepository;
import com.cg.EmployeeManagement.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	public UserService userService;
	@Autowired
	public UserRepository userRepository;

	@PostMapping("/insertuser")
	public ResponseEntity<User> insertUser(@RequestBody User user) {

		User result = userService.insertUser(user);
		return new ResponseEntity<User>(result, HttpStatus.OK);
	}

	@GetMapping("/getalluser")
	public List<User> getAllUsers() {

		List<User> result = userService.getAllUsers();
		return result;
	}

	@DeleteMapping("/deleteuserbyid/{id}")
	public void deleteUserById(@PathVariable int userid) {
		Optional<User> user = userRepository.findById(userid);
		userService.deleteUserbyId(user.get());
	}

	@GetMapping("/validate")
	public User validateUser(User user) {
		try {
			return userService.validateUser(user);
		} catch (DatabaseOperationException | BusinessException | ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}
}