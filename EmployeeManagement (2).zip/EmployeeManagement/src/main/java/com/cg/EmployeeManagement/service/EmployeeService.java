package com.cg.EmployeeManagement.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.EmployeeManagement.exceptions.ApplicationException;
import com.cg.EmployeeManagement.exceptions.BusinessException;
import com.cg.EmployeeManagement.exceptions.DatabaseOperationException;
import com.cg.EmployeeManagement.model.Employee;
import com.cg.EmployeeManagement.repository.EmployeeRepository;


@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	public Employee addEmployee(Employee employee)throws DatabaseOperationException, ApplicationException, BusinessException
	{
		return employeeRepository.save(employee);
	}
	
	public void deleteEmployee(int empId) throws DatabaseOperationException, ApplicationException
	{
		employeeRepository.deleteById(empId);
		
	}
	public Employee updateEmployee(Employee employee)throws DatabaseOperationException, ApplicationException, BusinessException
	{
		return employeeRepository.save(employee);
		
	}
	public List<Employee> getAllEmployees() throws DatabaseOperationException, ApplicationException
	{
		return employeeRepository.findAll();
	}
	public Employee getEmployeeById(int userId) throws DatabaseOperationException, ApplicationException
	{
		return employeeRepository.getEmployeeById(userId);
	}
	public List<Employee> getAllEmployeesByPagination(String maxPage, String ofset) throws DatabaseOperationException, ApplicationException
	{
		return employeeRepository.findAll();   
	}
	public long getAllEmployeeCount() throws DatabaseOperationException, ApplicationException
	{
		return employeeRepository.count();    
	}

	public boolean existsById(int userId) {
		if(employeeRepository.existsById(userId))
		{
			return true;
		}
		else
		{
			
	
		return false;
		}
	}


	
}