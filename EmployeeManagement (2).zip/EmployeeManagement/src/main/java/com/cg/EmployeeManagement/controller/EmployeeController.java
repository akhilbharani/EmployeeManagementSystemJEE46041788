package com.cg.EmployeeManagement.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.EmployeeManagement.exceptions.ApplicationException;
import com.cg.EmployeeManagement.exceptions.BusinessException;
import com.cg.EmployeeManagement.exceptions.DatabaseOperationException;
import com.cg.EmployeeManagement.model.Employee;
import com.cg.EmployeeManagement.service.EmployeeService;




@RestController
@RequestMapping("/employees")
public class EmployeeController {

	@Autowired
	public EmployeeService employeeService;
	
	@PostMapping("/addemployeedetails")
	public ResponseEntity<Employee> addEmployeeDetails(@RequestBody Employee employee)
	{ 
		
		try {
			Employee result = employeeService.addEmployee(employee);
			return new ResponseEntity<Employee>(result, HttpStatus.OK);
		} catch (ApplicationException | DatabaseOperationException | BusinessException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	@DeleteMapping("/deleteemployeebyid/{id}")
	public void deleteEmployeeById(@PathVariable int empId) {
		try {
			employeeService.deleteEmployee(empId);
		} catch (ApplicationException | DatabaseOperationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@PutMapping("/updateemployee")
	public Employee updateEmployee(Employee employee)  {
		try {
			boolean exists=employeeService.existsById(employee.getUserId());
			if(exists) {
				
			employeeService.updateEmployee(employee);
			return employee;
			}
			else
			{
				throw new BusinessException("employee not found");
			}
		}catch (ApplicationException | DatabaseOperationException | BusinessException e) {
			
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	
	@GetMapping("/getallemployeedetails")
	public List<Employee> getAllEmployeeDetails()  {
		
		
		try {
			List<Employee> result = employeeService.getAllEmployees();
		return result;
			
		} catch (ApplicationException | DatabaseOperationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
	@GetMapping("/getemployee")
	public List<Employee> getEmployeeById(@PathVariable int userId)  {
		
		
		try {
			Employee result = employeeService.getEmployeeById(userId);
			
		} catch (ApplicationException | DatabaseOperationException e) {
			
			e.printStackTrace();
		}
		return null;
		
	}
	
	@GetMapping("/getallemployeesbypagination")
	public List<Employee> getAllDepartmentDetailsByPagination()
			 {
		
		try {
			List<Employee> result = employeeService.getAllEmployeesByPagination(null, null);
			return result;
			
		} catch (ApplicationException | DatabaseOperationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
	
	@GetMapping("/getallemployeecount")
	public long getAllDepartmentCount() {
		try {
			return employeeService.getAllEmployeeCount();
		} catch (DatabaseOperationException | ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
		
	}
	
}